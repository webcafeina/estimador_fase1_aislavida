jQuery(document).ready(function($) {

    setTimeout(function() {
        if (window.innerWidth <= 580) {
            // Considera esto como un dispositivo móvil
            var elemento = document.getElementById("estimador");
            elemento.scrollIntoView({ behavior: 'smooth' });
        }
    }, 200);

    // RECUPERAMOS LAS VARIABLES DEL PANEL DE CONFIGURACIÓN PASADAS DEL PHP
    const estimador_webhook_url = estimadorData.estimador_webhook_url;
    const estimador_correo_admin = estimadorData.estimador_correo_admin;
    const estimador_precio_paredes_menos50 = estimadorData.estimador_precio_paredes_menos50;
    const estimador_precio_paredes_entre50_75 = estimadorData.estimador_precio_paredes_entre50_75;
    const estimador_precio_paredes_entre75_100 = estimadorData.estimador_precio_paredes_entre75_100;
    const estimador_precio_paredes_entre100_125 = estimadorData.estimador_precio_paredes_entre100_125;
    const estimador_precio_paredes_entre125_175 = estimadorData.estimador_precio_paredes_entre125_175;
    const estimador_precio_paredes_mas175 = estimadorData.estimador_precio_paredes_mas175;
    const estimador_precio_cubierta_entre50_60 = estimadorData.estimador_precio_cubierta_entre50_60;
    const estimador_precio_cubierta_entre60_70 = estimadorData.estimador_precio_cubierta_entre60_70;
    const estimador_precio_cubierta_entre70_80 = estimadorData.estimador_precio_cubierta_entre70_80;
    const estimador_precio_cubierta_entre80_90 = estimadorData.estimador_precio_cubierta_entre80_90;
    const estimador_precio_cubierta_entre90_100 = estimadorData.estimador_precio_cubierta_entre90_100;
    const estimador_precio_cubierta_mas100 = estimadorData.estimador_precio_cubierta_mas100;
    const estimador_apertura_financiacion_3 = estimadorData.estimador_apertura_financiacion_3;
    const estimador_apertura_financiacion_6 = estimadorData.estimador_apertura_financiacion_6;
    const estimador_apertura_financiacion_10 = estimadorData.estimador_apertura_financiacion_10;
    const estimador_apertura_financiacion_12 = estimadorData.estimador_apertura_financiacion_12;
    const estimador_apertura_financiacion_18 = estimadorData.estimador_apertura_financiacion_18;
    const estimador_apertura_financiacion_24 = estimadorData.estimador_apertura_financiacion_24;
    const estimador_apertura_financiacion_36 = estimadorData.estimador_apertura_financiacion_36;

    // Lógica de bandera de tienePrecio
    var tienePrecio = false;
    function actualizarBanderaTienePrecio(booleano) {
        tienePrecio = booleano;
        
        if(tienePrecio == true) {
            $("#estimador #financiacionCTA").removeAttr('disabled');
            $("#estimador #financiacionCTA").text("");
            $("#estimador #financiacionCTA").text("Solicitar presupuesto");
        } else if(tienePrecio == false) {
            $("#estimador #financiacionCTA").attr('disabled', true);
            $("#estimador #financiacionCTA").text("");
            $("#estimador #financiacionCTA").text("Selecciona una opción");
        }
    }

    // Establecer porcentaje de comisión de apertura por defecto al cargar la página
    $("#comision_dinamica").text(estimador_apertura_financiacion_3);


    // Control para que solo se quede seleccionado un checkbox de cada grupo
    $('#estimador input[type="checkbox"]').change(function(){
        if($(this).is(':checked')){
          $(this).closest('div.input_cont').find('input[type="checkbox"]').not(this).prop('checked', false);
        }
    });

    // Manejo de los inputs de radio de elección entre tejado y cubierta
    $('#estimador input[type="radio"]').change(function(){
        $('.toggle-label').removeClass('selected'); 
        $(this).next('label').addClass('selected');
    });

    // Función para manejar la visibilidad de los divs de paredes o cubierta y deseleccionar los checkboxes ocultados
    function actualizarVisibilidadParedesCubierta() {
        if($('#pared').is(':checked')) {
            $('#tamanoPared_cont').show();
            $('#tamanoCubierta_cont').hide().find('input[type="checkbox"]').prop('checked', false);

            $("#totalEstimacion #estimacionDinamica").text("");
            $("#totalEstimacion #estimacionDinamica").text("0");

            $("#totalEstimacionContado span").text("");
            $("#totalEstimacionContado span").text("0");

            $("#comision_calculada_dinamica").text("");
            $("#comision_calculada_dinamica").text("0");

            actualizarBanderaTienePrecio(false);

        } else if($('#cubierta').is(':checked')) {
            $('#tamanoPared_cont').hide().find('input[type="checkbox"]').prop('checked', false);
            $('#tamanoCubierta_cont').show();

            $("#totalEstimacion #estimacionDinamica").text("");
            $("#totalEstimacion #estimacionDinamica").text("0");

            $("#totalEstimacionContado span").text("");
            $("#totalEstimacionContado span").text("0");

            $("#comision_calculada_dinamica").text("");
            $("#comision_calculada_dinamica").text("0");

            actualizarBanderaTienePrecio(false);
        }
    }

    // Llamar a la función al cargar la página para establecer la visibilidad correcta
    actualizarVisibilidadParedesCubierta();

    // Actualizar la visibilidad cuando se cambia la selección de los radio buttons
    $('input[type="radio"][name="eleccionParedCubierta"]').change(function(){
        actualizarVisibilidadParedesCubierta();

        if (window.innerWidth <= 580) {
            // Considera esto como un dispositivo móvil
            var elementoToggles = document.getElementById("toggles_cont");
            elementoToggles.scrollIntoView({ behavior: 'smooth' });
        }
    });

    // Control para desactivar los checkboxes de tamaños si los de tipo de vivienda no están seleccionados
    function ajustarCheckboxesTamanos() {
        // Verificar el estado de los checkboxes específicos
        var viviendaIndependiente = $('#viviendaIndependiente').is(':checked');
        var viviendaEdificio = $('#viviendaEdificio').is(':checked');

        // Determinar si los checkboxes deben estar habilitados o no
        var habilitar = viviendaIndependiente || viviendaEdificio;

        // Seleccionar los checkboxes dentro de los divs y ajustar según corresponda
        $('#tamanoPared_cont input[type="checkbox"], #tamanoCubierta_cont input[type="checkbox"]').each(function() {
            $(this).prop('disabled', !habilitar); // Habilita o deshabilita basado en la variable habilitar
            if (!habilitar) {
                $(this).prop('checked', false); // Desmarca si están deshabilitados
                $("#totalEstimacion #estimacionDinamica").text("");
                $("#totalEstimacion #estimacionDinamica").text("0");

                $("#totalEstimacionContado span").text("");
                $("#totalEstimacionContado span").text("0");

                $("#comision_calculada_dinamica").text("");
                $("#comision_calculada_dinamica").text("0");

                actualizarBanderaTienePrecio(false);
            }
        });
    }

    // Ejecutar al cargar la página
    ajustarCheckboxesTamanos();

    // También ejecutar cada vez que se cambie el estado de los checkboxes relevantes
    $('#viviendaIndependiente, #viviendaEdificio').change(function() {
        ajustarCheckboxesTamanos();

        if($(this).is(':checked')) {
            if (window.innerWidth <= 580) {
                // Considera esto como un dispositivo móvil
                var elementoTogglesTamano = document.getElementById("columnaDerecha");
                elementoTogglesTamano.scrollIntoView({ behavior: 'smooth' });
            }
        }
    });

    // Función para pasar a 0 la estimación si se desactivan todos los checkboxes de un grupo
    function actualizarTotalEstimacionA0() {
        // Verifica si el div está visible Y todos los checkboxes dentro de él están desactivados
        if (($('#tamanoPared_cont').is(':visible') && $('#tamanoPared_cont input[type="checkbox"]:checked').length === 0) ||
            ($('#tamanoCubierta_cont').is(':visible') && $('#tamanoCubierta_cont input[type="checkbox"]:checked').length === 0)) {
            
            $("#totalEstimacion #estimacionDinamica").text("");
            $("#totalEstimacion #estimacionDinamica").text("0");

            $("#totalEstimacionContado span").text("");
            $("#totalEstimacionContado span").text("0");

            $("#comision_calculada_dinamica").text("");
            $("#comision_calculada_dinamica").text("0");

            actualizarBanderaTienePrecio(false);
        }
    }
    
    // Función para actualizar los datos de financiación
    function actualizarFinanciacion(toggleInfo, valorMeses) {
        switch(toggleInfo) {
            case '0_50':
                $("#totalEstimacion #estimacionDinamica").text("");
                $("#totalEstimacion #estimacionDinamica").text(parseFloat(estimador_precio_paredes_menos50 / parseInt(valorMeses)).toFixed(2));

                $("#totalEstimacionContado span").text("");
                $("#totalEstimacionContado span").text(parseFloat(estimador_precio_paredes_menos50).toFixed(2));

                switch(valorMeses) {
                    case '3':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_menos50 * estimador_apertura_financiacion_3) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));

                    break;
        
                    case '6':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_menos50 * estimador_apertura_financiacion_6) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '10':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_menos50 * estimador_apertura_financiacion_10) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '12':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_menos50 * estimador_apertura_financiacion_12) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                        
                    case '18':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_menos50 * estimador_apertura_financiacion_18) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '24':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_menos50 * estimador_apertura_financiacion_24) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '36':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_menos50 * estimador_apertura_financiacion_36) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                }
            break;
            case '50_75':
                $("#totalEstimacion #estimacionDinamica").text("");
                $("#totalEstimacion #estimacionDinamica").text(parseFloat(estimador_precio_paredes_entre50_75 / parseInt(valorMeses)).toFixed(2));

                $("#totalEstimacionContado span").text("");
                $("#totalEstimacionContado span").text(parseFloat(estimador_precio_paredes_entre50_75).toFixed(2));

                switch(valorMeses) {
                    case '3':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre50_75 * estimador_apertura_financiacion_3) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));

                    break;
        
                    case '6':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre50_75 * estimador_apertura_financiacion_6) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '10':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre50_75 * estimador_apertura_financiacion_10) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '12':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre50_75 * estimador_apertura_financiacion_12) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                        
                    case '18':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre50_75 * estimador_apertura_financiacion_18) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '24':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre50_75 * estimador_apertura_financiacion_24) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '36':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre50_75 * estimador_apertura_financiacion_36) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                }
            break;
            case '75_100':
                $("#totalEstimacion #estimacionDinamica").text("");
                $("#totalEstimacion #estimacionDinamica").text(parseFloat(estimador_precio_paredes_entre75_100 / parseInt(valorMeses)).toFixed(2));

                $("#totalEstimacionContado span").text("");
                $("#totalEstimacionContado span").text(parseFloat(estimador_precio_paredes_entre75_100).toFixed(2));

                switch(valorMeses) {
                    case '3':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre75_100 * estimador_apertura_financiacion_3) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));

                    break;
        
                    case '6':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre75_100 * estimador_apertura_financiacion_6) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '10':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre75_100 * estimador_apertura_financiacion_10) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '12':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre75_100 * estimador_apertura_financiacion_12) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                        
                    case '18':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre75_100 * estimador_apertura_financiacion_18) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '24':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre75_100 * estimador_apertura_financiacion_24) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '36':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre75_100 * estimador_apertura_financiacion_36) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                }
            break;
            case '100_125':
                $("#totalEstimacion #estimacionDinamica").text("");
                $("#totalEstimacion #estimacionDinamica").text(parseFloat(estimador_precio_paredes_entre100_125 / parseInt(valorMeses)).toFixed(2));

                $("#totalEstimacionContado span").text("");
                $("#totalEstimacionContado span").text(parseFloat(estimador_precio_paredes_entre100_125).toFixed(2));

                switch(valorMeses) {
                    case '3':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre100_125 * estimador_apertura_financiacion_3) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));

                    break;
        
                    case '6':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre100_125 * estimador_apertura_financiacion_6) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '10':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre100_125 * estimador_apertura_financiacion_10) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '12':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre100_125 * estimador_apertura_financiacion_12) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                        
                    case '18':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre100_125 * estimador_apertura_financiacion_18) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '24':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre100_125 * estimador_apertura_financiacion_24) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '36':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre100_125 * estimador_apertura_financiacion_36) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                }
            break;
            case '125_175':
                $("#totalEstimacion #estimacionDinamica").text("");
                $("#totalEstimacion #estimacionDinamica").text(parseFloat(estimador_precio_paredes_entre125_175 / parseInt(valorMeses)).toFixed(2));

                $("#totalEstimacionContado span").text("");
                $("#totalEstimacionContado span").text(parseFloat(estimador_precio_paredes_entre125_175).toFixed(2));

                switch(valorMeses) {
                    case '3':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre125_175 * estimador_apertura_financiacion_3) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));

                    break;
        
                    case '6':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre125_175 * estimador_apertura_financiacion_6) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '10':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre125_175 * estimador_apertura_financiacion_10) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '12':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre125_175 * estimador_apertura_financiacion_12) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                        
                    case '18':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre125_175 * estimador_apertura_financiacion_18) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '24':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre125_175 * estimador_apertura_financiacion_24) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '36':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_entre125_175 * estimador_apertura_financiacion_36) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                }
            break;
            case '175':
                $("#totalEstimacion #estimacionDinamica").text("");
                $("#totalEstimacion #estimacionDinamica").text(parseFloat(estimador_precio_paredes_mas175 / parseInt(valorMeses)).toFixed(2));

                $("#totalEstimacionContado span").text("");
                $("#totalEstimacionContado span").text(parseFloat(estimador_precio_paredes_mas175).toFixed(2));

                switch(valorMeses) {
                    case '3':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_mas175 * estimador_apertura_financiacion_3) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));

                    break;
        
                    case '6':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_mas175 * estimador_apertura_financiacion_6) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '10':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_mas175 * estimador_apertura_financiacion_10) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '12':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_mas175 * estimador_apertura_financiacion_12) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                        
                    case '18':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_mas175 * estimador_apertura_financiacion_18) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '24':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_mas175 * estimador_apertura_financiacion_24) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '36':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_paredes_mas175 * estimador_apertura_financiacion_36) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                }
            break;
            case '50_60':
                $("#totalEstimacion #estimacionDinamica").text("");
                $("#totalEstimacion #estimacionDinamica").text(parseFloat(estimador_precio_cubierta_entre50_60 / parseInt(valorMeses)).toFixed(2));

                $("#totalEstimacionContado span").text("");
                $("#totalEstimacionContado span").text(parseFloat(estimador_precio_cubierta_entre50_60).toFixed(2));

                switch(valorMeses) {
                    case '3':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre50_60 * estimador_apertura_financiacion_3) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));

                    break;
        
                    case '6':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre50_60 * estimador_apertura_financiacion_6) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '10':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre50_60 * estimador_apertura_financiacion_10) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '12':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre50_60 * estimador_apertura_financiacion_12) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                        
                    case '18':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre50_60 * estimador_apertura_financiacion_18) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '24':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre50_60 * estimador_apertura_financiacion_24) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '36':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre50_60 * estimador_apertura_financiacion_36) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                }
            break;
            case '60_70':
                $("#totalEstimacion #estimacionDinamica").text("");
                $("#totalEstimacion #estimacionDinamica").text(parseFloat(estimador_precio_cubierta_entre60_70 / parseInt(valorMeses)).toFixed(2));

                $("#totalEstimacionContado span").text("");
                $("#totalEstimacionContado span").text(parseFloat(estimador_precio_cubierta_entre60_70).toFixed(2));

                switch(valorMeses) {
                    case '3':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre60_70 * estimador_apertura_financiacion_3) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));

                    break;
        
                    case '6':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre60_70 * estimador_apertura_financiacion_6) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '10':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre60_70 * estimador_apertura_financiacion_10) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '12':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre60_70 * estimador_apertura_financiacion_12) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                        
                    case '18':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre60_70 * estimador_apertura_financiacion_18) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '24':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre60_70 * estimador_apertura_financiacion_24) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '36':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre60_70 * estimador_apertura_financiacion_36) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                }
            break;
            case '70_80':
                $("#totalEstimacion #estimacionDinamica").text("");
                $("#totalEstimacion #estimacionDinamica").text(parseFloat(estimador_precio_cubierta_entre70_80 / parseInt(valorMeses)).toFixed(2));

                $("#totalEstimacionContado span").text("");
                $("#totalEstimacionContado span").text(parseFloat(estimador_precio_cubierta_entre70_80).toFixed(2));

                switch(valorMeses) {
                    case '3':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre70_80 * estimador_apertura_financiacion_3) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));

                    break;
        
                    case '6':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre70_80 * estimador_apertura_financiacion_6) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '10':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre70_80 * estimador_apertura_financiacion_10) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '12':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre70_80 * estimador_apertura_financiacion_12) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                        
                    case '18':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre70_80 * estimador_apertura_financiacion_18) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '24':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre70_80 * estimador_apertura_financiacion_24) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '36':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre70_80 * estimador_apertura_financiacion_36) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                }
            break;
            case '80_90':
                $("#totalEstimacion #estimacionDinamica").text("");
                $("#totalEstimacion #estimacionDinamica").text(parseFloat(estimador_precio_cubierta_entre80_90 / parseInt(valorMeses)).toFixed(2));

                $("#totalEstimacionContado span").text("");
                $("#totalEstimacionContado span").text(parseFloat(estimador_precio_cubierta_entre80_90).toFixed(2));

                switch(valorMeses) {
                    case '3':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre80_90 * estimador_apertura_financiacion_3) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));

                    break;
        
                    case '6':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre80_90 * estimador_apertura_financiacion_6) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '10':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre80_90 * estimador_apertura_financiacion_10) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '12':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre80_90 * estimador_apertura_financiacion_12) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                        
                    case '18':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre80_90 * estimador_apertura_financiacion_18) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '24':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre80_90 * estimador_apertura_financiacion_24) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '36':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre80_90 * estimador_apertura_financiacion_36) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                }
            break;
            case '90_100':
                $("#totalEstimacion #estimacionDinamica").text("");
                $("#totalEstimacion #estimacionDinamica").text(parseFloat(estimador_precio_cubierta_entre90_100 / parseInt(valorMeses)).toFixed(2));

                $("#totalEstimacionContado span").text("");
                $("#totalEstimacionContado span").text(parseFloat(estimador_precio_cubierta_entre90_100).toFixed(2));

                switch(valorMeses) {
                    case '3':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre90_100 * estimador_apertura_financiacion_3) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));

                    break;
        
                    case '6':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre90_100 * estimador_apertura_financiacion_6) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '10':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre90_100 * estimador_apertura_financiacion_10) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '12':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre90_100 * estimador_apertura_financiacion_12) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                        
                    case '18':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre90_100 * estimador_apertura_financiacion_18) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '24':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre90_100 * estimador_apertura_financiacion_24) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '36':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_entre90_100 * estimador_apertura_financiacion_36) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                }
            break;
            case '100':
                $("#totalEstimacion #estimacionDinamica").text("");
                $("#totalEstimacion #estimacionDinamica").text(parseFloat(estimador_precio_cubierta_mas100 / parseInt(valorMeses)).toFixed(2));

                $("#totalEstimacionContado span").text("");
                $("#totalEstimacionContado span").text(parseFloat(estimador_precio_cubierta_mas100).toFixed(2));

                switch(valorMeses) {
                    case '3':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_mas100 * estimador_apertura_financiacion_3) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));

                    break;
        
                    case '6':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_mas100 * estimador_apertura_financiacion_6) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '10':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_mas100 * estimador_apertura_financiacion_10) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '12':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_mas100 * estimador_apertura_financiacion_12) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                        
                    case '18':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_mas100 * estimador_apertura_financiacion_18) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '24':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_mas100 * estimador_apertura_financiacion_24) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
        
                    case '36':
                        $("#comision_calculada_dinamica").text("");
                        $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((estimador_precio_cubierta_mas100 * estimador_apertura_financiacion_36) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                    break;
                }
            break;

        }

        actualizarBanderaTienePrecio(true);

    }

    function normalizarFinanciacion(toggleInfo) {
        switch(toggleInfo) {
            case '0_50':
                return 'Menos de 50 m²';

            case '50_75':
                return 'Entre 50 y 75 m²';

            case '75_100':
                return 'Entre 75 y 100 m²';
            
            case '100_125':
                return 'Entre 100 y 125 m²';
            
            case '125_175':
                return 'Entre 125 y 175 m²';
            
            case '175':
                return 'Más de 175 m²';
            
            case '50_60':
                return 'Entre 50 y 60 m²';
            
            case '60_70':
                return 'Entre 60 y 70 m²';
            
            case '70_80':
                return 'Entre 70 y 80 m²';
            
            case '80_90':
                return 'Entre 80 y 90 m²';
            
            case '90_100':
                return 'Entre 90 y 100 m²';
            
            case '100':
                return 'Más de 100 m²';

        }

    }

    // Cambiar el precio según los metros de paredes o cubierta al elegir toggle
    $('#estimador input[type="checkbox"]').change(function() {
        var checkboxSeleccionado = $(this).attr('id');
        if($('#pared').is(':checked')) {
            console.log("PARED");
            switch(checkboxSeleccionado) {
                case '0_50':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('0_50', spanMeses); 
                break;
                case '50_75':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('50_75', spanMeses); 
                break;
                case '75_100':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('75_100', spanMeses); 
                break;
                case '100_125':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('100_125', spanMeses); 
                break;
                case '125_175':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('125_175', spanMeses); 
                break;
                case '175':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('175', spanMeses); 
                break;
            }
        } else if($('#cubierta').is(':checked')) {
            console.log("CUBIERTA");
            switch(checkboxSeleccionado) {
                case '50_60':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('50_60', spanMeses); 
                break;
                case '60_70':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('60_70', spanMeses); 
                break;
                case '70_80':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('70_80', spanMeses); 
                break;
                case '80_90':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('80_90', spanMeses); 
                break;
                case '90_100':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('90_100', spanMeses); 
                break;
                case '100':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('100', spanMeses); 
                break;
            }
        }

        actualizarTotalEstimacionA0();
    });


    // Lógica de funcionamiento para el slider de financiación
    const slider = document.getElementById('sliderRango');
    const valorSlider = document.getElementById('valorSlider');
    const valores = [3, 6, 10, 12, 18, 24, 36];

    slider.addEventListener('input', function() {
        valorSlider.textContent = valores[this.value];

        if ($('#tamanoPared_cont').is(':visible') && $('#tamanoPared_cont input[type="checkbox"]:checked').length != 0) {
            
            var checkboxFinanciacionSeleccionado = $('#tamanoPared_cont input[type="checkbox"]:checked').attr('id');

            switch(checkboxFinanciacionSeleccionado) {
                case '0_50':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('0_50', spanMeses); 
                break;
                case '50_75':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('50_75', spanMeses); 
                break;
                case '75_100':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('75_100', spanMeses); 
                break;
                case '100_125':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('100_125', spanMeses); 
                break;
                case '125_175':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('125_175', spanMeses); 
                break;
                case '175':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('175', spanMeses); 
                break;
            }

        } else if ($('#tamanoCubierta_cont').is(':visible') && $('#tamanoCubierta_cont input[type="checkbox"]:checked').length != 0) {

            var checkboxFinanciacionSeleccionado = $('#tamanoCubierta_cont input[type="checkbox"]:checked').attr('id');

            switch(checkboxFinanciacionSeleccionado) {
                case '50_60':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('50_60', spanMeses); 
                break;
                case '60_70':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('60_70', spanMeses); 
                break;
                case '70_80':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('70_80', spanMeses); 
                break;
                case '80_90':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('80_90', spanMeses); 
                break;
                case '90_100':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('90_100', spanMeses); 
                break;
                case '100':
                    var spanMeses = $("#valorSlider").text();
                    actualizarFinanciacion('100', spanMeses); 
                break;
            }

        }

        var spanMesesPorcentaje = $("#valorSlider").text();
        var precioSinFinanciar = parseFloat($("#totalEstimacionContado span").text()).toFixed(2);

        switch(spanMesesPorcentaje) {
            case '3':
                $("#comision_dinamica").text(estimador_apertura_financiacion_3);

                if(precioSinFinanciar != 0) {
                    $("#comision_calculada_dinamica").text("");
                    $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((precioSinFinanciar * estimador_apertura_financiacion_3) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                }
            break;

            case '6':
                $("#comision_dinamica").text(estimador_apertura_financiacion_6);

                if(precioSinFinanciar != 0) {
                    $("#comision_calculada_dinamica").text("");
                    $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((precioSinFinanciar * estimador_apertura_financiacion_6) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                }
            break;

            case '10':
                $("#comision_dinamica").text(estimador_apertura_financiacion_10);

                if(precioSinFinanciar != 0) {
                    $("#comision_calculada_dinamica").text("");
                    $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((precioSinFinanciar * estimador_apertura_financiacion_10) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                }
            break;

            case '12':
                $("#comision_dinamica").text(estimador_apertura_financiacion_12);

                if(precioSinFinanciar != 0) {
                    $("#comision_calculada_dinamica").text("");
                    $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((precioSinFinanciar * estimador_apertura_financiacion_12) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                }
            break;
                
            case '18':
                $("#comision_dinamica").text(estimador_apertura_financiacion_18);

                if(precioSinFinanciar != 0) {
                    $("#comision_calculada_dinamica").text("");
                    $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((precioSinFinanciar * estimador_apertura_financiacion_18) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                }
            break;

            case '24':
                $("#comision_dinamica").text(estimador_apertura_financiacion_24);

                if(precioSinFinanciar != 0) {
                    $("#comision_calculada_dinamica").text("");
                    $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((precioSinFinanciar * estimador_apertura_financiacion_24) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                }
            break;

            case '36':
                $("#comision_dinamica").text(estimador_apertura_financiacion_36);

                if(precioSinFinanciar != 0) {
                    $("#comision_calculada_dinamica").text("");
                    $("#comision_calculada_dinamica").text((resultadoApertura = parseFloat((precioSinFinanciar * estimador_apertura_financiacion_36) / 100).toFixed(2), resultadoApertura >= 30 ? resultadoApertura : "30.00"));
                }
            break;
        }
        
        
    });

    // Lógica del modal de financiación
    // Al hacer clic en el botón para abrir el modal
    $("#financiacionCTA").click(function() {
        $("#modalFinanciacion").show();
    });

    // Al hacer clic en el botón de cerrar (x), cierra el modal
    $(".close").click(function() {
        $("#modalFinanciacion").hide();
    });

    // Al hacer clic fuera del modal, también lo cierra
    $(window).click(function(event) {
        if ($(event.target).is(".modal-background")) {
            $("#modalFinanciacion").hide();
        }
    });

    // Lógica de envío de datos personales a Holded
    $("#submitFinanciacion").on('click', function() {
        if($('#nombreFinanciacion').val() == '') {
            if($('#modalFinanciacion #nombreFinanciacion_cont span.mensajeValidacion').html() != '') {
                $('#modalFinanciacion #nombreFinanciacion_cont span.mensajeValidacion').html('');
                $('#modalFinanciacion #nombreFinanciacion_cont input').css('border-color', '#99999e');
            }

            if($('#modalFinanciacion #nombreFinanciacion_cont span.mensajeValidacion').html() == 0) {
                $('#modalFinanciacion #nombreFinanciacion_cont span.mensajeValidacion').html('Este campo no puede estar vacío');
                $('#modalFinanciacion #nombreFinanciacion_cont input').css('border-color', 'red');
            }


        } else if($('#apellidosFinanciacion').val() == '') {
            $('#modalFinanciacion span.mensajeValidacion').html('');
            $('#modalFinanciacion input').css('border-color', '#99999e');
            $('#modalFinanciacion select').css('border-color', '#99999e');

            if($('#modalFinanciacion #apellidosFinanciacion_cont span.mensajeValidacion').html() != '') {
                $('#modalFinanciacion #apellidosFinanciacion_cont span.mensajeValidacion').html('');
                $('#modalFinanciacion #apellidosFinanciacion_cont input').css('border-color', '#99999e');
            }

            if($('#modalFinanciacion #apellidosFinanciacion_cont span.mensajeValidacion').html() == 0) {
                $('#modalFinanciacion #apellidosFinanciacion_cont span.mensajeValidacion').html('Este campo no puede estar vacío');
                $('#modalFinanciacion #apellidosFinanciacion_cont input').css('border-color', 'red');
            }
            
        } else if($('#correoFinanciacion').val() == '') {
            $('#modalFinanciacion span.mensajeValidacion').html('');
            $('#modalFinanciacion input').css('border-color', '#99999e');
            $('#modalFinanciacion select').css('border-color', '#99999e');

            if($('#modalFinanciacion #correoFinanciacion_cont span.mensajeValidacion').html() != '') {
                $('#modalFinanciacion #correoFinanciacion_cont span.mensajeValidacion').html('');
                $('#modalFinanciacion #correoFinanciacion_cont input').css('border-color', '#99999e');
            }

            if($('#modalFinanciacion #correoFinanciacion_cont span.mensajeValidacion').html() == 0) {
                $('#modalFinanciacion #correoFinanciacion_cont span.mensajeValidacion').html('Este campo no puede estar vacío');
                $('#modalFinanciacion #correoFinanciacion_cont input').css('border-color', 'red');
            }
            

        } else if($('#telefonoFinanciacion').val() == '') {
            $('#modalFinanciacion span.mensajeValidacion').html('');
            $('#modalFinanciacion input').css('border-color', '#99999e');
            $('#modalFinanciacion select').css('border-color', '#99999e');

            if($('#modalFinanciacion #telefonoFinanciacion_cont span.mensajeValidacion').html() != '') {
                $('#modalFinanciacion #telefonoFinanciacion_cont span.mensajeValidacion').html('');
                $('#modalFinanciacion #telefonoFinanciacion_cont input').css('border-color', '#99999e');
            }

            if($('#modalFinanciacion #telefonoFinanciacion_cont span.mensajeValidacion').html() == 0) {
                $('#modalFinanciacion #telefonoFinanciacion_cont span.mensajeValidacion').html('Este campo no puede estar vacío');
                $('#modalFinanciacion #telefonoFinanciacion_cont input').css('border-color', 'red');
            }

        } else if($('#municipioFinanciacion').val() == '') {
            $('#modalFinanciacion span.mensajeValidacion').html('');
            $('#modalFinanciacion input').css('border-color', '#99999e');
            $('#modalFinanciacion select').css('border-color', '#99999e');

            if($('#modalFinanciacion #municipioFinanciacion_cont span.mensajeValidacion').html() != '') {
                $('#modalFinanciacion #municipioFinanciacion_cont span.mensajeValidacion').html('');
                $('#modalFinanciacion #municipioFinanciacion_cont input').css('border-color', '#99999e');
            }

            if($('#modalFinanciacion #municipioFinanciacion_cont span.mensajeValidacion').html() == 0) {
                $('#modalFinanciacion #municipioFinanciacion_cont span.mensajeValidacion').html('Este campo no puede estar vacío');
                $('#modalFinanciacion #municipioFinanciacion_cont input').css('border-color', 'red');
            }

        } else if($('#provinciaFinanciacion').val() == '') {
            $('#modalFinanciacion span.mensajeValidacion').html('');
            $('#modalFinanciacion input').css('border-color', '#99999e');
            $('#modalFinanciacion select').css('border-color', '#99999e');

            if($('#modalFinanciacion #provinciaFinanciacion_cont span.mensajeValidacion').html() != '') {
                $('#modalFinanciacion #provinciaFinanciacion_cont span.mensajeValidacion').html('');
                $('#modalFinanciacion #provinciaFinanciacion_cont select').css('border-color', '#99999e');
            }

            if($('#modalFinanciacion #provinciaFinanciacion_cont span.mensajeValidacion').html() == 0) {
                $('#modalFinanciacion #provinciaFinanciacion_cont span.mensajeValidacion').html('Este campo no puede estar vacío');
                $('#modalFinanciacion #provinciaFinanciacion_cont select').css('border-color', 'red');
            }
        } else {
            $('#modalFinanciacion span.mensajeValidacion').html('');
            $('#modalFinanciacion input').css('border-color', '#99999e');
            $('#modalFinanciacion select').css('border-color', '#99999e');


            if(!$('#nombreFinanciacion').val().match(/^[a-zA-ZáéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ\s\-\']+$/)) {
                if($('#modalFinanciacion #nombreFinanciacion_cont span.mensajeValidacion').html() != '') {
                    $('#modalFinanciacion #nombreFinanciacion_cont span.mensajeValidacion').html('');
                    $('#modalFinanciacion #nombreFinanciacion_cont input').css('border-color', '#99999e');
                }
    
                if($('#modalFinanciacion #nombreFinanciacion_cont span.mensajeValidacion').html() == 0) {
                    $('#modalFinanciacion #nombreFinanciacion_cont span.mensajeValidacion').html('Introduce un formato correcto');
                    $('#modalFinanciacion #nombreFinanciacion_cont input').css('border-color', 'red');
                }


            } else if(!$('#apellidosFinanciacion').val().match(/^[a-zA-ZáéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ\s\-\']+$/)) {
                $('#modalFinanciacion span.mensajeValidacion').html('');
                $('#modalFinanciacion input').css('border-color', '#99999e');
                $('#modalFinanciacion select').css('border-color', '#99999e');

                if($('#modalFinanciacion #apellidosFinanciacion_cont span.mensajeValidacion').html() != '') {
                    $('#modalFinanciacion #apellidosFinanciacion_cont span.mensajeValidacion').html('');
                    $('#modalFinanciacion #apellidosFinanciacion_cont input').css('border-color', '#99999e');
                }

                if($('#modalFinanciacion #apellidosFinanciacion_cont span.mensajeValidacion').html() == 0) {
                    $('#modalFinanciacion #apellidosFinanciacion_cont span.mensajeValidacion').html('Introduce un formato correcto');
                    $('#modalFinanciacion #apellidosFinanciacion_cont input').css('border-color', 'red');
                }

            } else if(!$('#correoFinanciacion').val().match(/^[a-zA-Z0-9\._-]+@[a-zA-Z0-9-]{2,}[.][a-zA-Z]{2,4}$/)) {
                $('#modalFinanciacion span.mensajeValidacion').html('');
                $('#modalFinanciacion input').css('border-color', '#99999e');
                $('#modalFinanciacion select').css('border-color', '#99999e');

                if($('#modalFinanciacion #correoFinanciacion_cont span.mensajeValidacion').html() != '') {
                    $('#modalFinanciacion #correoFinanciacion_cont span.mensajeValidacion').html('');
                    $('#modalFinanciacion #correoFinanciacion_cont input').css('border-color', '#99999e');
                }

                if($('#modalFinanciacion #correoFinanciacion_cont span.mensajeValidacion').html() == 0) {
                    $('#modalFinanciacion #correoFinanciacion_cont span.mensajeValidacion').html('Introduce un correo electrónico correcto');
                    $('#modalFinanciacion #correoFinanciacion_cont input').css('border-color', 'red');
                }

            } else if(!$('#telefonoFinanciacion').val().match(/^(\+34|0034|34)?[6789]\d{8}$/)) {
                $('#modalFinanciacion span.mensajeValidacion').html('');
                $('#modalFinanciacion input').css('border-color', '#99999e');
                $('#modalFinanciacion select').css('border-color', '#99999e');

                if($('#modalFinanciacion #telefonoFinanciacion_cont span.mensajeValidacion').html() != '') {
                    $('#modalFinanciacion #telefonoFinanciacion_cont span.mensajeValidacion').html('');
                    $('#modalFinanciacion #telefonoFinanciacion_cont input').css('border-color', '#99999e');
                }

                if($('#modalFinanciacion #telefonoFinanciacion_cont span.mensajeValidacion').html() == 0) {
                    $('#modalFinanciacion #telefonoFinanciacion_cont span.mensajeValidacion').html('Introduce un teléfono correcto');
                    $('#modalFinanciacion #telefonoFinanciacion_cont input').css('border-color', 'red');
                }

            } else if(!$('#municipioFinanciacion').val().match(/^[a-zA-ZáéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ\s\-\']+$/)) {
                $('#modalFinanciacion span.mensajeValidacion').html('');
                $('#modalFinanciacion input').css('border-color', '#99999e');
                $('#modalFinanciacion select').css('border-color', '#99999e');

                if($('#modalFinanciacion #municipioFinanciacion_cont span.mensajeValidacion').html() != '') {
                    $('#modalFinanciacion #municipioFinanciacion_cont span.mensajeValidacion').html('');
                    $('#modalFinanciacion #municipioFinanciacion_cont input').css('border-color', '#99999e');
                }

                if($('#modalFinanciacion #municipioFinanciacion_cont span.mensajeValidacion').html() == 0) {
                    $('#modalFinanciacion #municipioFinanciacion_cont span.mensajeValidacion').html('Introduce un formato correcto');
                    $('#modalFinanciacion #municipioFinanciacion_cont input').css('border-color', 'red');
                }
            } else {
                $('#modalFinanciacion span.mensajeValidacion').html('');
                $('#modalFinanciacion input').css('border-color', '#99999e');
                $('#modalFinanciacion select').css('border-color', '#99999e');

                if(!$("#politicaFinanciacion").is(':checked')) {
                    $('#modalFinanciacion #politicaFinanciacion_cont span.mensajeValidacion').html('');
                    $('#modalFinanciacion #politicaFinanciacion_cont span.mensajeValidacion').html('Debes aceptar las políticas de privacidad');
                } else {
                    $('#modalFinanciacion #politicaFinanciacion_cont span.mensajeValidacion').html('');


                    /* TODA LA VALIDACIÓN ESTÁ OK */
                    var aislarParedesCubierta_enviar = $("#estimador #eleccionParedCubierta_cont label.selected").attr("for");
                    var tipoVivienda_enviar = $("#estimador #tipoVivienda_cont input:checked").attr("id");
                    var tamano_enviar = $("#estimador #columnaDerecha input:checked").attr("id");
                    var precioFinanciado_enviar = $("#estimador #totalEstimacion #estimacionDinamica").text();
                    var precioSinFinanciar_enviar = $("#estimador #totalEstimacionContado span").text();
                    var comisionApertura_enviar = $("#estimador #comision_apertura #comision_dinamica").text();
                    var aperturaCalculada_enviar = $("#estimador #comision_apertura_calculada #comision_calculada_dinamica").text();
                    var mesesFinanciacion_enviar = $("#estimador .slider_financiacion_cont #valorSlider").text();

                    if(aislarParedesCubierta_enviar == "pared") {
                        aislarParedesCubierta_enviar = "Paredes";
                    } else if(aislarParedesCubierta_enviar == "cubierta") {
                        aislarParedesCubierta_enviar = "Cubierta";
                    }

                    if(tipoVivienda_enviar == "viviendaIndependiente") {
                        tipoVivienda_enviar = "Vivienda independiente";
                    } else if(tipoVivienda_enviar == "viviendaEdificio") {
                        tipoVivienda_enviar = "Vivienda en un edificio";
                    }
                    var tamanoNormalizado_enviar = normalizarFinanciacion(tamano_enviar);


                    var nombre_enviar = $("#nombreFinanciacion").val();
                    var apellidos_enviar = $("#apellidosFinanciacion").val();
                    var correo_enviar = $("#correoFinanciacion").val();
                    var telefono_enviar = $("#telefonoFinanciacion").val();
                    var municipio_enviar = $("#municipioFinanciacion").val();
                    var provincia_enviar = $("#provinciaFinanciacion").val();

                    /* PREPARAMOS ENVÍO A ZAPIER */
                    var nota_enviar = `Aisla paredes o cubierta: ${aislarParedesCubierta_enviar} | Tipo de vivienda: ${tipoVivienda_enviar} | Tamaño de vivienda: ${tamanoNormalizado_enviar} | Precio financiado: ${precioFinanciado_enviar} € | Precio sin financiar: ${precioSinFinanciar_enviar} € | Comisión de apertura: ${comisionApertura_enviar} % | Cuantía de apertura: ${aperturaCalculada_enviar} € | Meses de financiación: ${mesesFinanciacion_enviar}`;

                    var datosUsuario_enviar = {
                        "name": nombre_enviar + " " + apellidos_enviar,
                        "email": correo_enviar,
                        "phone": telefono_enviar,
                        "city": municipio_enviar,
                        "state": provincia_enviar,
                        "tags": ["usuario_fase1"],
                        "note": nota_enviar
                    };

                    $.ajax({
                        url: estimador_webhook_url,
                        type: "POST",
                        data: JSON.stringify(datosUsuario_enviar),
                        success: function(response) {

                            var datos_email = {
                                'action': 'enviar_email',
                                'correo_admin': estimador_correo_admin,
                                'nombre_usuario': nombre_enviar,
                                'apellidos_usuario': apellidos_enviar,
                                'telefono_usuario': telefono_enviar,
                                'correo_usuario': correo_enviar,
                                'municipio_usuario': municipio_enviar,
                                'provincia_usuario': provincia_enviar,
                                'paredes_cubierta': aislarParedesCubierta_enviar,
                                'tipo_vivienda': tipoVivienda_enviar,
                                'tamano_vivienda': tamanoNormalizado_enviar,
                                'precio_financiado': precioFinanciado_enviar,
                                'precio_sinFinanciar': precioSinFinanciar_enviar,
                                'comision_apertura': comisionApertura_enviar,
                                'cuantia_apertura': aperturaCalculada_enviar,
                                'meses_financiacion': mesesFinanciacion_enviar
                            }

                            $.post(ajax_object.ajax_url, datos_email, function(respuesta_email) {
                                if(respuesta_email.success) {
                                    console.log('Correo a admin enviado con éxito');
                                    window.location.href = 'https://aislavida.com/estimacion-enviada';
                                } else {
                                    console.log('Error al enviar el correo a admin: ' + respuesta_email.error);
                                }

                            });
                            
                        },
                        error: function(xhr, status, error) {
                            console.error("Error al enviar datos de usuario a Zapier", xhr, status, error);
                        }
                    });

                }
            }
        }
    });
});